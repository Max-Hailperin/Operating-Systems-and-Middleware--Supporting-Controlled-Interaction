import java.rmi.RemoteException;

public interface Topic extends MessageRecipient {
  void subscribe(MessageRecipient subscriber)
    throws RemoteException;
}
